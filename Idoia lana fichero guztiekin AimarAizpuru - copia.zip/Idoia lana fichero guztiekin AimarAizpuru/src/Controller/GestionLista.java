/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Coches;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author DM3-2-02
 */
public class GestionLista {

    public static ObservableList<Coches> datuKarga() {
        return FXCollections.observableArrayList(
//                new Coches("Bugatti ", "Chiron", "i6789w",3, false),
//                new Coches("Peugeot", "Johnson", "iiop899w",4, true),
//                new Coches("BMW", "Williams", "i6734589w",2, false),
//                new Coches("Mercedes", "Jones", "i6789w",6, false),
//                new Coches("Bugatti ", "Brown", "i6789w",6, true),
//                new Coches("Bugatti ", "Brown", "i6789w",6, true),
//                new Coches("Bugatti ", "Brown", "i6789w",6, false),
//                new Coches("Bugatti ", "Brown", "i6789w",6, true),
//                new Coches("Bugatti ", "Brown", "i6789w",6, false),
//                new Coches("Bugatti ", "Brown", "i6789w",6, true)
        );
    }
}
